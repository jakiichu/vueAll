let person1 = true;
let i;
let app = new Vue({
  el: '.gamePilon',
  data: {
      message: ['1',"2",'3','4','5','6','7','8','9'],
      person2: false
  },
  methods: {

    addPilon: function(i) {
      if(person1){
        this.message[i] = "x"
        person1 = !person1;
        
        
      }
      else{
        
        this.message[i] = "0"
        person1 = !person1;
      }
    }
  }
});

